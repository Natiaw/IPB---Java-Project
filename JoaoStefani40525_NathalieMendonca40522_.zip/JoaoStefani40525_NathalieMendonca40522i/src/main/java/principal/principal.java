package principal;
import trab1.Empresa;

/**
 *
 * 
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empresa emp = new Empresa();
        
        emp.addCliente("Joao");
        System.out.println("--------Criação de cliente duplicado:-------------");
        emp.addCliente("Joao");
        System.out.println("--------------------------------------------------");
        emp.addCliente("Nathi");
        emp.addCliente("Milton");
        
        emp.addProduto("Calcado", "nike");
        System.out.println("-------------Criação de produto duplicado:--------");
        emp.addProduto("Calcado", "nike");
        System.out.println("--------------------------------------------------");
        emp.addProduto("Calca", "Tiffosi");
        emp.addProduto("Jogo", "Brandili");
        emp.addProduto("Boneco", "Marvel");
        
        System.out.println("--------Catálogo de produtos da loja:-------------");
        System.out.println(emp.catalogoToString());
        System.out.println("--------------------------------------------------");
        System.out.println("-----------Clientes da loja-----------------------");
        System.out.println(emp.clientesToString());
        System.out.println("--------------------------------------------------");
        
        emp.addEncomendaProduto(1, 2);
        emp.addEncomendaProduto(1, 1);
        emp.addEncomendaProduto(2, 3);
        emp.addEncomendaProduto(3, 1);
        
        
        System.out.println("--------------Encomendas invalidas----------------");
        emp.addEncomendaProduto(10, 2);
        emp.addEncomendaProduto(1, 15);
        emp.addEncomendaProduto(10, 15);
        System.out.println("--------------------------------------------------");
        
        System.out.println("--------Clientes da loja e respectivas encomendas:-------------");
        System.out.println(emp.clientesToString());
        System.out.println("---------------------------------------------------------------");
        
        emp.closeEncomenda(1);
        emp.closeEncomenda(2);
        emp.closeEncomenda(3);
        
        System.out.println("--------Clientes da loja e respectivas encomendas:-------------");
        System.out.println(emp.clientesToString());
        System.out.println("---------------------------------------------------------------");
        
        
        emp.addEncomendaProduto(1, 3);
        emp.addEncomendaProduto(1, 2);
        emp.addEncomendaProduto(2, 1);
        emp.addEncomendaProduto(3, 2);
        
        System.out.println("--------Clientes da loja e respectivas encomendas:-------------");
        System.out.println(emp.clientesToString());
        System.out.println("---------------------------------------------------------------");
        
        emp.closeEncomenda(1);
        emp.closeEncomenda(2);
        emp.closeEncomenda(3);
        System.out.println("--------Clientes da loja e respectivas encomendas:-------------");
        System.out.println(emp.clientesToString());
        System.out.println("---------------------------------------------------------------");
        
    }
    
}
