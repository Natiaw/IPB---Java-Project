package trab1;

import java.util.LinkedList;

enum estado{aberta, fechada};

/**
 *
 * 
 */
public class Encomenda {
    private int codencomenda;
    private estado estado;
    private LinkedList<Integer> produtos;
    
    
    /**
     * 
     * @param cod codigo de encomenda a ser criada no sistema.
     */
    public Encomenda(int cod){
        codencomenda = cod;
        this.estado = estado.aberta;
        produtos = new LinkedList<>();
    }
    
    /**
     * 
     * @return estado da encomenda em questao, aberta ou fechada.
     */
    public estado getEstado(){
            return this.estado;
    }
    
    /**
     * 
     * @param estado novo estado para a encomenda em questao.
     */
    public void setEstado(estado estado){
        this.estado = estado;
    }
    
    /**
     * 
     * @param codproduto codigo do produto a ser adicionado na encomenda em questao.
     * @return true se o produto for adicionado com sucesso, false se nao.
     * 
     */
    public boolean addProduto(int codproduto){
        return produtos.add(codproduto);   
    }
    /**
     * 
     * @return uma string contendo todas as informacoes da encomenda em questao.
     * 
     */
    @Override
    public String toString(){
        String str = "Codigo de encomenda: " + codencomenda + ". Estado: " + estado + "\n" + "Produtos encomendados (por codigo):" + "\n";
        for(Integer p : produtos){
            str += p + "\n";
        }
        return str;
    }
}



