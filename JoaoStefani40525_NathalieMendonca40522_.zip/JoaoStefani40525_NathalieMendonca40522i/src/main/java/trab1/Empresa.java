package trab1;

import java.util.LinkedList;

/**
 *
 * @author Nathalie Mendonca (a40522)
 * @author Joao Stefani (a40525)
 */
public class Empresa {
    private LinkedList<Cliente> clientes;
    private LinkedList<Produto> produtos;
    
    
   /**
    * 
    */
    public Empresa(){
        clientes = new LinkedList<>();
        produtos = new LinkedList<>();
    }
    
     /**
    *
    * @param nome e' o nome que o cliente criado devera' ter no sistema.
    * @return true se a adicao a lista for em exito, falso se o contrario.
    * 
    */
    public boolean addCliente(String nome){
        
        Cliente c;
        //verificar se a lista esta vazia, neste caso criar o cliente com codigo 1.
        if(clientes.isEmpty()){
            c = new Cliente(1, nome);
        }        
        
        else{
            for(Cliente cl : clientes){ //nao podem existir dois clientes com o mesmo nome.
                if(cl.getNome().equals(nome)){
                    System.out.println("Não podem existir dois clientes com o mesmo nome! (" + nome + ")");
                    return false;
                }
            }//se lista nao estiver vazia, getCodigo + 1
            int cod = clientes.getLast().getCodCliente() + 1;
            c = new Cliente(cod, nome);
        }
        return clientes.add(c);
        
    }
    
    
    /**
    *
    * @param designacao e' a designação que o produto criado devera ter no sistema.
    * @param marca e' a marca que o produto devera ter no sistema
    * @return true se a adicao a lista for em êxito, falso se o contrario.
    * 
    */
    public boolean addProduto(String designacao, String marca){
        Produto p;
        if(produtos.isEmpty()){
            p = new Produto(1, designacao, marca);
        }
         
        else{
            for(Produto pr : produtos){
                if((pr.getDesignacao().equals(designacao)) && (pr.getMarca().equals(marca))){
                    System.out.println("Não podem existir dois produtos com a mesma designação e marca ao mesmo tempo! (" + designacao + ", " + marca + ")");
                return false;
                }
            }
            int cod = produtos.getLast().getCodProduto() + 1;
            p = new Produto(cod, designacao, marca);
        }
       
        return produtos.add(p);
    }
    /**
     * 
     * @param codProduto codigo do produto a ser procurado na lista do sistema.
     * @return  true se o produto existir, false se nao.
     */
    public boolean existeProduto(int codProduto){
        for(Produto p : produtos){
            if(p.getCodProduto() == codProduto) return true;
        }
        return false;
    }
    
    /**
     * 
     * @param codcliente e o codigo do cliente a ser procurado na lista do sistema.
     * @return true se o cliente existir, false se nao
     */
    public boolean existeCliente(int codcliente){
        for(Cliente c : clientes){
            if(c.getCodCliente() == codcliente) return true;
        }
        return false;
    }
    
    /**
     * 
     * @param codcliente e' o codigo do cliente ao qual a encomenda deve ser atribuida.
     * @param codproduto e' o codigo do produto a ser incluido no inicio da lista de produtos da encomenda.
     * @return true se a encomenda for criada com sucesso em Cliente, false se nao.
     */
    public boolean addEncomendaProduto(int codcliente, int codproduto){
        if(existeCliente(codcliente)){
            if(existeProduto(codproduto)){
        for(Cliente c : clientes){
            if(c.getCodCliente() == codcliente){
                for(Produto p : produtos){
                    if(p.getCodProduto() == codproduto)
                        return c.addEncomenda(codproduto);
                   
                }
               
            } 
        }
        return false;
    } else {
                System.out.println("Impossivel encomendar produto inexistente. código " + codproduto);
                return false;
            }
        } else{
            System.out.println("Impossivel encomendar produto a cliente que não está registrado. código " + codcliente);
                return false;
        }
    }
    /**
     * 
     * @param codcliente codigo do cliente no qual deve-se procurar uma encomenda aberta para fechar.
     * @return true se for encontrada uma encomenda e esta for fechada, false se nao.
     */
    public boolean closeEncomenda(int codcliente){
        if(existeCliente(codcliente))
        for(Cliente c : clientes){
            if(c.getCodCliente() == codcliente){
                return c.closeEncomenda();
            }
        }
        return false;
    }
    
    /**
     * 
     * @return uma string contendo as informacoes de todos os produtos do sistema.
     */
    public String catalogoToString(){
        String aux = "";
        for(Produto p : produtos){
            aux += p.toString() + "\n";
        }
        return aux;
    }
    
    /**
     * 
     * @return uma string contendo as informacoes de todos os clientes do sistema e suas respectivas encomendas. 
     */
    public String clientesToString(){
        String aux = "";
        for(Cliente c : clientes){
            aux += c.toString() + "\n";
        }
        return aux;
    }
}
