package trab1;

/**
 *
 * 
 */
public class Produto {
    private int codproduto;
    private String designacao;
    private String marca;
    /**
     * 
     * @param cod codigo do produto a ser criado no sistema.
     * @param des designacao do produto a ser criado no sistema.
     * @param marca marca do produto a ser criado no sistema.
     */
    public Produto(int cod, String des, String marca){
        codproduto = cod;
        designacao = des;
        this.marca = marca;
    }
    
    /**
     * 
     * @return codigo do produto em questao.
     */
    public int getCodProduto(){
        return codproduto;
    }
    
    /**
     * 
     * @return designação do produto em questao.
     */
    public String getDesignacao(){
        return designacao;
    }
    
    /**
     * 
     * @return marca do produto em questao.
     */
    public String getMarca(){
        return marca;
    }
    /**
     * 
     * @return uma string com as informacoes do produto em questao.
     */
    @Override
    public String toString(){
        return "Codigo de produto: " + codproduto + ". Designacao: " + designacao + ". Marca: " + marca;
    }
}
