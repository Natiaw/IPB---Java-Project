package trab1;

import java.util.LinkedList;

/**
 *
 * 
 */
public class Cliente {
    private int codCliente;
    private String nome;
    private LinkedList<Encomenda> encomendas;
    
    /**
     * 
     * @param cod codigo do cliente que esta sendo criado.
     * @param nome nome do cliente que esta sendo criado.
     */
    public Cliente(int cod, String nome){
        codCliente = cod;
        this.nome = nome;
        encomendas = new LinkedList<>();
    }
    
    /**
     * 
     * @return codigo do cliente em questao para uso na classe Empresa.
     */
    public int getCodCliente(){
        return codCliente;
    }
    
    /**
     * 
     * @return nome do cliente em questao para uso na classe Empresa.
     */
    public String getNome(){
        return nome;
    }
    
    /**
     * 
     * @param codproduto codigo do produto a ser adicionado na encomenda a ser criada para o cliente em questao.
     * @return true se a encomenda for criada com sucesso, false se nao.
     */
    public boolean addEncomenda(int codproduto){ 
        
        for(Encomenda enco : encomendas){
            if(enco.getEstado() == estado.aberta){
               return enco.addProduto(codproduto);
                
            }
        }
        Encomenda enc;
        if(encomendas.isEmpty()){
            enc = new Encomenda(1);
            enc.addProduto(codproduto);
            return encomendas.add(enc);
        }
        int i = 1;
        for(Encomenda en : encomendas){
            i++;
        }
        enc = new Encomenda(i);
        enc.addProduto(codproduto);
        return encomendas.add(enc);
    }
    
    /**
     * 
     * @return true se for encontrada uma encomenda aberta e esta for fechada com sucesso, false se nao.
     */
    public boolean closeEncomenda(){
        
        for(Encomenda enc : encomendas){
            if(enc.getEstado() == estado.aberta){
                enc.setEstado(estado.fechada);
                return true;
            }
        }
        System.out.println("Não existe encomenda aberta para fechar.");
        return false;
    }
    /**
     * 
     * @return uma string contendo todas as informações do cliente em questao e suas respectivas encomendas.
     */
    @Override
    public String toString(){
        String str = "";
        if(encomendas.isEmpty()){
            str += "\nCodigo de cliente: " + codCliente + ". Nome: " + nome;
            str += "\ncliente ainda não efetuou encomendas na loja.";
            return str;
        }
        Encomenda e = new Encomenda(-1);
        int aux = 0;
        
        for(Encomenda enc : encomendas){
            if(enc.getEstado() == estado.aberta){ e = enc; aux++; }
        }
        if(aux == 1){
        str += "\nCodigo de cliente: " + codCliente + ". Nome: " + nome + ".\n Encomenda Aberta: " + e.toString();
         for(Encomenda enc : encomendas){
             if(enc.getEstado() == estado.fechada)
            str += enc.toString();
        }
         return str;
        } else{
            str += "\nCodigo de cliente: " + codCliente + ". Nome: " + nome + ".\n Encomendas: \n";
             for(Encomenda enc : encomendas){
            str += enc.toString();
        }
             return str;
        } 
    }
    
    
}
